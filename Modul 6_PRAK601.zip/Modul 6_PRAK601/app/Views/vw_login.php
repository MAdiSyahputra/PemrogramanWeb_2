<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.79.0">
    <title>Login Page</title>

    <style>
        body {
            background-image: url('https://images.pexels.com/photos/2041540/pexels-photo-2041540.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .form-signin {
            width: 100%;
            max-width: 330px;
            padding: 15px;
            background-color: rgba(255, 255, 255, 0.8);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
        }

        .form-signin h1 {
            font-size: 1.5em;
            margin-bottom: 1em;
        }

        .form-signin input {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-left: auto;
            margin-right: auto;
            display: block;
        }

        .form-signin button {
            width: calc(100% - 22px);
            padding: 10px;
            border: 2px solid transparent;
            border-radius: 4px;
            background-color: transparent;
            color: #007bff;
            font-size: 1em;
            cursor: pointer;
            transition: color 0.3s;
            margin-left: auto;
            margin-right: auto;
            display: block;
        }

        .form-signin button:hover {
            color: #0056b3;
        }

        .alert {
            padding: 10px;
            background-color: #f9edbe;
            color: #856404;
            border: 1px solid #ffeeba;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .text-muted {
            color: #6c757d;
        }
    </style>
</head>

<body>

    <main class="form-signin">
    <div class="alert" id="initial-alert">
    Login terlebih dahulu!
        <?php if (!empty(session()->getFlashdata('error'))) : ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <?php echo session()->getFlashdata('error'); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?= base_url(); ?>/login/process">
            <?= csrf_field(); ?>
            <h1 class="h3 mb-3 fw-normal">Login</h1>
            <input type="text" name="username" id="username" placeholder="Username" required autofocus>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <button type="submit">Login</button>
            <p class="mt-5 mb-3 text-muted">&copy; Warung Belajar</p>
        </form>
    </main>
    <script>
        window.onload = function() {
            document.getElementById('initial-alert').style.display = 'block';
        }
    </script>

</body>

</html>
